package com.college.cms.repository;

import com.college.cms.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends MongoRepository<Student, String> {

    Optional<Student> findByEnrollmentNumber(String enrollmentNumber);

    List<Student> findByDepartmentId(String departmentId);

    List<Student> findByCourse(String course);

    List<Student> findByYear(int year);
}
