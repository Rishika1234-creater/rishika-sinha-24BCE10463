package com.college.cms.controller;

import com.college.cms.model.Book;
import com.college.cms.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        return ResponseEntity.status(201)
                .body(bookService.addBook(book));
    }

    @GetMapping
    public ResponseEntity<List<Book>> getBooks() {
        return ResponseEntity.ok(bookService.getAllBooks());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBook(@PathVariable String id) {
        return bookService.getBookById(id)
                .map(book -> ResponseEntity.ok(book))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/isbn/{isbn}")
    public ResponseEntity<Book> getByIsbn(@PathVariable String isbn) {
        return bookService.getBookByIsbn(isbn)
                .map(book -> ResponseEntity.ok(book))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/category/{category}")
    public ResponseEntity<List<Book>> getByCategory(@PathVariable String category) {
        return ResponseEntity.ok(bookService.getBooksByCategory(category));
    }

    @GetMapping("/available")
    public ResponseEntity<List<Book>> availableBooks() {
        return ResponseEntity.ok(bookService.getAvailableBooks());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable String id,
                                           @RequestBody Book book) {
        try {
            return ResponseEntity.ok(bookService.updateBook(id, book));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{bookId}/borrow/{studentId}")
    public ResponseEntity<Book> borrowBook(@PathVariable String bookId,
                                           @PathVariable String studentId) {
        try {
            return ResponseEntity.ok(
                    bookService.borrowBook(bookId, studentId)
            );
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/{bookId}/return/{studentId}")
    public ResponseEntity<Book> returnBook(@PathVariable String bookId,
                                           @PathVariable String studentId) {
        try {
            return ResponseEntity.ok(
                    bookService.returnBook(bookId, studentId)
            );
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable String id) {
        try {
            return ResponseEntity.ok(bookService.deleteBook(id));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}