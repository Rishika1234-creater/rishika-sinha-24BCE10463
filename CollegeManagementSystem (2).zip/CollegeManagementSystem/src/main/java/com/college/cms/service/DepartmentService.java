package com.college.cms.service;

import com.college.cms.model.Department;
import com.college.cms.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;
    public Department addDepartment(Department department) {
        return departmentRepository.save(department);
    }
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }
    public Optional<Department> getDepartmentById(String id) {
        return departmentRepository.findById(id);
    }
    public Optional<Department> getDepartmentByCode(String code) {
        return departmentRepository.findByCode(code);
    }
    public Department updateDepartment(String id, Department updatedDepartment) {
        Optional<Department> existing = departmentRepository.findById(id);
        if (existing.isPresent()) {
            updatedDepartment.setId(id);
            return departmentRepository.save(updatedDepartment);
        }
        throw new RuntimeException("Department not found with id: " + id);
    }
    public Department assignStudentToDepartment(String deptId, String studentId) {
        Department department = departmentRepository.findById(deptId)
                .orElseThrow(() -> new RuntimeException("Department not found with id: " + deptId));

        if (!department.getStudentIds().contains(studentId)) {
            department.getStudentIds().add(studentId);
            return departmentRepository.save(department);
        }
        return department;
    }
    public Department assignStaffToDepartment(String deptId, String staffId) {
        Department department = departmentRepository.findById(deptId)
                .orElseThrow(() -> new RuntimeException("Department not found with id: " + deptId));

        if (!department.getStaffIds().contains(staffId)) {
            department.getStaffIds().add(staffId);
            return departmentRepository.save(department);
        }
        return department;
    }
    public String deleteDepartment(String id) {
        if (departmentRepository.existsById(id)) {
            departmentRepository.deleteById(id);
            return "Department deleted successfully with id: " + id;
        }
        throw new RuntimeException("Department not found with id: " + id);
    }
}
