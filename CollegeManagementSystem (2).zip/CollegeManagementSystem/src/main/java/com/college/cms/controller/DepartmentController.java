package com.college.cms.controller;

import com.college.cms.model.Department;
import com.college.cms.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @PostMapping
    public ResponseEntity<Department> addDepartment(@RequestBody Department department) {
        Department dept = departmentService.addDepartment(department);
        return ResponseEntity.status(201).body(dept);
    }

    @GetMapping
    public List<Department> getDepartments() {
        return departmentService.getAllDepartments();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Department> getDepartment(@PathVariable String id) {
        return departmentService.getDepartmentById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/code/{code}")
    public ResponseEntity<Department> getDepartmentByCode(@PathVariable String code) {
        return departmentService.getDepartmentByCode(code)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateDepartment(@PathVariable String id,
                                              @RequestBody Department department) {
        try {
            return ResponseEntity.ok(
                    departmentService.updateDepartment(id, department)
            );
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{deptId}/assign-student/{studentId}")
    public ResponseEntity<?> assignStudent(@PathVariable String deptId,
                                           @PathVariable String studentId) {
        try {
            return ResponseEntity.ok(
                    departmentService.assignStudentToDepartment(deptId, studentId)
            );
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/{deptId}/assign-staff/{staffId}")
    public ResponseEntity<?> assignStaff(@PathVariable String deptId,
                                         @PathVariable String staffId) {
        try {
            return ResponseEntity.ok(
                    departmentService.assignStaffToDepartment(deptId, staffId)
            );
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteDepartment(@PathVariable String id) {
        try {
            departmentService.deleteDepartment(id);
            return ResponseEntity.ok("Department deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}