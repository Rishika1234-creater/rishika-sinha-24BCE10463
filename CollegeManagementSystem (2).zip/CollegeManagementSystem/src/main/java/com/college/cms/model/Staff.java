package com.college.cms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "staff")
public class Staff {

    @Id
    private String id;

    private String name;
    private String email;
    private String phone;
    private String address;
    private String employeeId;
    private String designation;
    private String qualification;
    private double salary;

    private String departmentId;
}
