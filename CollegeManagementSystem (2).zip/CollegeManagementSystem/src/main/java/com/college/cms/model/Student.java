package com.college.cms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "students")
public class Student {

    @Id
    private String id;

    private String name;
    private String email;
    private String phone;
    private String address;
    private String enrollmentNumber;
    private String course;
    private int year;

    private String departmentId;
    private List<String> bookIds;
}
