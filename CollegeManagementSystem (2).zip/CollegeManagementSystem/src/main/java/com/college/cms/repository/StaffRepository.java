package com.college.cms.repository;

import com.college.cms.model.Staff;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StaffRepository extends MongoRepository<Staff, String> {

    Optional<Staff> findByEmployeeId(String employeeId);

    List<Staff> findByDepartmentId(String departmentId);

    List<Staff> findByDesignation(String designation);
}
