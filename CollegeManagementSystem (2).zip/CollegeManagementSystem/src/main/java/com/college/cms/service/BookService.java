package com.college.cms.service;

import com.college.cms.model.Book;
import com.college.cms.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public Book addBook(Book book) {
        return bookRepository.save(book);
    }

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Optional<Book> getBookById(String id) {
        return bookRepository.findById(id);
    }
    public Optional<Book> getBookByIsbn(String isbn) {
        return bookRepository.findByIsbn(isbn);
    }
    public List<Book> getBooksByCategory(String category) {
        return bookRepository.findByCategory(category);
    }
    public List<Book> getAvailableBooks() {
        return bookRepository.findByAvailableCopiesGreaterThan(0);
    }
    public Book updateBook(String id, Book updatedBook) {
        Optional<Book> existing = bookRepository.findById(id);
        if (existing.isPresent()) {
            updatedBook.setId(id);
            return bookRepository.save(updatedBook);
        }
        throw new RuntimeException("Book not found with id: " + id);
    }
    public Book borrowBook(String bookId, String studentId) {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found with id: " + bookId));

        if (book.getAvailableCopies() <= 0) {
            throw new RuntimeException("No copies available for book: " + book.getTitle());
        }

        if (!book.getBorrowedByStudentIds().contains(studentId)) {
            book.getBorrowedByStudentIds().add(studentId);
            book.setAvailableCopies(book.getAvailableCopies() - 1);
            return bookRepository.save(book);
        }
        throw new RuntimeException("Student has already borrowed this book.");
    }
    public Book returnBook(String bookId, String studentId) {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found with id: " + bookId));

        if (book.getBorrowedByStudentIds().remove(studentId)) {
            book.setAvailableCopies(book.getAvailableCopies() + 1);
            return bookRepository.save(book);
        }
        throw new RuntimeException("Student did not borrow this book.");
    }
    public String deleteBook(String id) {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
            return "Book deleted successfully with id: " + id;
        }
        throw new RuntimeException("Book not found with id: " + id);
    }
}
