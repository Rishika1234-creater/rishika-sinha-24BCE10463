package com.college.cms.service;

import com.college.cms.model.Staff;
import com.college.cms.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StaffService {

    @Autowired
    private StaffRepository staffRepository;
    public Staff addStaff(Staff staff) {
        return staffRepository.save(staff);
    }
    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }
    public Optional<Staff> getStaffById(String id) {
        return staffRepository.findById(id);
    }

  
    public Optional<Staff> getStaffByEmployeeId(String employeeId) {
        return staffRepository.findByEmployeeId(employeeId);
    }
    public List<Staff> getStaffByDepartment(String departmentId) {
        return staffRepository.findByDepartmentId(departmentId);
    }
    public List<Staff> getStaffByDesignation(String designation) {
        return staffRepository.findByDesignation(designation);
    }
    public Staff updateStaff(String id, Staff updatedStaff) {
        Optional<Staff> existing = staffRepository.findById(id);
        if (existing.isPresent()) {
            updatedStaff.setId(id);
            return staffRepository.save(updatedStaff);
        }
        throw new RuntimeException("Staff not found with id: " + id);
    }
    public String deleteStaff(String id) {
        if (staffRepository.existsById(id)) {
            staffRepository.deleteById(id);
            return "Staff deleted successfully with id: " + id;
        }
        throw new RuntimeException("Staff not found with id: " + id);
    }
}
